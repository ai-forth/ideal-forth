\ Error strings
\ This file is in public domain

>rom
s" Aborted" -&1 ErrLink linkstring
s" Undefined word" -&13 ErrLink linkstring
s" Stack underflow" -&4 ErrLink linkstring
s" Interpreting a compile-only word" -&14 ErrLink linkstring
s" Control structure mismatch" -&22 ErrLink linkstring
\ s" Pictured numeric ouput string overflow" -&17 ErrLink linkstring
s" Attempt to use zero-length string as a name" -&16 ErrLink linkstring
>ram


