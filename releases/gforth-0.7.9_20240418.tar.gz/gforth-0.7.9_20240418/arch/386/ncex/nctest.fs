
\ 1may00jaw

include ./ncex.fs
\ include disasm.fs

native

: t1 1 2 dup + + ;

threaded
