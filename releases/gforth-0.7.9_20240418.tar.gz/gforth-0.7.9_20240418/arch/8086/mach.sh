#! /bin/sh

cp $1- gf8086.com
cp $1- $1