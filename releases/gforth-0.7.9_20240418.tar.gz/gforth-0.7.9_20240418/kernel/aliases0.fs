\ run-time routine headers

\ Authors: Anton Ertl, Bernd Paysan, David Kühling
\ Copyright (C) 1997,1998,2002,2003,2006,2007,2010,2013,2015,2016,2019,2021,2023 Free Software Foundation, Inc.

\ This file is part of Gforth.

\ Gforth is free software; you can redistribute it and/or
\ modify it under the terms of the GNU General Public License
\ as published by the Free Software Foundation, either version 3
\ of the License, or (at your option) any later version.

\ This program is distributed in the hope that it will be useful,
\ but WITHOUT ANY WARRANTY; without even the implied warranty of
\ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
\ GNU General Public License for more details.

\ You should have received a copy of the GNU General Public License
\ along with this program. If not, see http://www.gnu.org/licenses/.

-2 Doer: :docol
-3 Doer: :docon
-3 Doer: :doacon
-4 Doer: :dovar
-5 Doer: :douser
-6 Doer: :dodefer
-7 Doer: :dofield
-8 Doer: :dovalue
-9 Doer: :dodoes
-9 Doer: :dodoes1
-9 Doer: :dodoes2
-9 Doer: :dodoes3
-9 Doer: :dodoes4
-9 Doer: :dodoes5
-9 Doer: :dodoes6
-9 Doer: :dodoes7
-9 Doer: :dodoes8
-9 Doer: :dodoes9
-&10 Doer: :doabicode
-&11 Doer: :do;abicode
-&2 first-primitive
\ this does not work for (at least) (DODOES),
\ so the following routines are commented out
