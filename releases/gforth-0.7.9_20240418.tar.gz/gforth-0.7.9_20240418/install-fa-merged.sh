#!/bin/sh

wget -c https://github.com/forthy42/Font-Awesome/raw/master/webfonts/fa-merged-900.ttf
sudo install -vDm 755 fa-merged-900.ttf /usr/share/fonts/truetype/emoji/fa-merged-900.ttf
